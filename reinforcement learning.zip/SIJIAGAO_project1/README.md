In this project, I proposed a Gaussian Mixture Model (GMM) to detect red barrels on images. 
For training stage, I built a GMM on red barrel pixels cropped from training images manually using Roipoly in Matlab. Pixels are represented in LAB colorspace. For test stage, I segmented red colors according to the trained GMM, then found contours and finally facilitated contour shape statistics to identify barrels out of other segmented pieces.

Instruction:
1. Place test images in "Test_Set"
2. Open "trainmodel.ipynb" to see the pipeline of trained GMM for red barrel pixels using EM algorithm. Resulted parameters including coefficient, mean and covariance are saved in  "store.pckl"
3. Open "fortest.ipynb", click "Cells---run all". The program will show output for each test image that include:
     (1) Color segmentated image: a binary (white-black) image and is saved in folder ''segment"
     (2) Barrel boundingbox,centroid and distance estimation shown on the original test image. Saved in folder "boundingbox"

