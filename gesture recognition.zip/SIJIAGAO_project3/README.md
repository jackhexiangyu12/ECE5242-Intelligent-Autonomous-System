Instruction:
1. Add folder 2019Proj2_test

2. Open "Proj3 demo" to see the pipeline of the proposed method: reconstruct robotic trajectory using encoder and rebuild map using lidar. Find cells for input and change the filename. A window appears as a online timer.

3. Results are shown in two figures: one for trajectory of the robot, the other one is the detected map in dark blue and yellow color. Yellow dots represent walls.


